# magento2-banners-slider
Banners Slider Extension For Magento 2

# See the videos about this tutorial
- Youtube: https://www.youtube.com/watch?v=JwxtiEwEZpk&list=PL98CDCbI3TNvvb0SvN_M35IToppFCHGg3
- Facebook: https://www.facebook.com/giaphugroupcom/videos/2063225743899973/

# Screenshot

*The brand slider demo*
![ScreenShot](https://github.com/php-cuong/magento2-banners-slider/blob/master/Screenshot/brand-list-demo.gif)

*The home slider demo*
![ScreenShot](https://github.com/php-cuong/magento2-banners-slider/blob/master/Screenshot/homeslider-demo.gif)

<?php

namespace Primenta\VideoWidget\Block\Widget;

use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface;

class Videowidget extends Template implements BlockInterface
{

    protected $_template = "widget/videowidget.phtml";

}

?>

